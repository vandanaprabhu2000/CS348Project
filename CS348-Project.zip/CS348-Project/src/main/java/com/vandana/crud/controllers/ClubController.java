package com.vandana.crud.controllers;

import com.vandana.crud.entities.Club;
import com.vandana.crud.entities.Student;
import com.vandana.crud.repositories.ClubRepository;
import com.vandana.crud.repositories.StudentRepository;
import com.vandana.crud.service.ClubService;
import com.vandana.crud.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@Controller
public class ClubController {
    @Autowired
    private final ClubRepository clubRepository;
    @Autowired
    private ClubService clubService;
    @Autowired
    public ClubController(ClubRepository clubRepository) {
        this.clubRepository = clubRepository;
    }
    @GetMapping("/add-club")
    public String showSignUpForm(Club club) {
        return "add-club";
    }
    @PostMapping("/addclub")
    public String addStudent(@Valid Club club, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("club", club);
            return "add-club";
        }
        long startTime = new Date().getTime();
        clubRepository.save(club);
        long endTime = new Date().getTime();
        System.out.println("Time to add a student in JDBC Template = " + (endTime - startTime));
        model.addAttribute("clubs", clubRepository.findAll());
        return "clubIndex";
    }
    @GetMapping("/clubEdit/{id}")
    public String showUpdateForm(@PathVariable("id") Integer id, Model model) {
        Club club = clubRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid club Id:" + id));
        model.addAttribute("club", club);
        return "update-club";
    }
    @PostMapping("/clubUpdate/{id}")
    public String updateStudent(@PathVariable("id") Integer id, @Valid Club club, BindingResult result, Model model) {
        if (result.hasErrors()) {
        //    student.setId(new ObjectId(id));
            return "update-club";
        }
        long startTime = new Date().getTime();
        clubRepository.update(club);
        long endTime = new Date().getTime();
        System.out.println("Time to update student in JDBC Template = " + (endTime - startTime));
        model.addAttribute("clubs", clubRepository.findAll());
        return "studentIndex";
    }
    @GetMapping("/clubDelete/{id}")
    public String deleteStudent(@PathVariable("id") Integer id, Model model) {
        Club club = clubRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user id:" + id));
        long startTime = new Date().getTime();
        clubRepository.deleteById(club.getId());
        long endTime = new Date().getTime();
        System.out.println("Time to delete a student in JDBC Template = " + (endTime - startTime));
        model.addAttribute("clubs", clubRepository.findAll());
        return "clubIndex";
    }
    @GetMapping("/clubIndex")
    public String listStudents(Model model) {
        List<Club> clubs = clubRepository.findAll();
        model.addAttribute("clubs", clubs);
        return "clubIndex";
    }
}