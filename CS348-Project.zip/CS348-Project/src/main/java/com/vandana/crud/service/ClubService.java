package com.vandana.crud.service;

import com.vandana.crud.entities.Club;
import com.vandana.crud.entities.Student;
import com.vandana.crud.repositories.ClubRepository;
import com.vandana.crud.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClubService {
    @Autowired
    private ClubRepository clubRepository;
    public void addtoClubs(Club s){
        clubRepository.save(s);
    }
    public List<Club> getClubs(){
        return clubRepository.findAll();
    }
    public Optional<Club> getClubById(Integer id){
        return clubRepository.findById(id);
    }
    public void deleteClub(Integer id){
        clubRepository.deleteById(id);
    }
    public void deleteClub(Club s){
        clubRepository.deleteById(s.getId());
    }
     public void setClubRepository(ClubRepository clubRepository) {
        this.clubRepository = clubRepository;
    }
}
