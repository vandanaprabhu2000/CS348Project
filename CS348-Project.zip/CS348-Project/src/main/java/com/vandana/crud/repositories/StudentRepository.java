package com.vandana.crud.repositories;
import com.vandana.crud.entities.Student;
import java.util.List;
import java.util.Optional;
public interface StudentRepository {
    int save(Student student);
    int update(Student student);
    int deleteById(Integer id);
    List<Student> findAll();
    Optional<Student> findById(Integer id);
}

