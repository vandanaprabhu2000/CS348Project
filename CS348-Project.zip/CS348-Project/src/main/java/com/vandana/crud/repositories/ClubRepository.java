package com.vandana.crud.repositories;

import com.vandana.crud.entities.Club;
import com.vandana.crud.entities.Student;

import java.util.List;
import java.util.Optional;

public interface ClubRepository {
    int save(Club club);
    int update(Club club);
    int deleteById(Integer id);
    List<Club> findAll();
    Optional<Club> findById(Integer id);
}

