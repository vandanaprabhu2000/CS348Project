package com.vandana.crud.entities;

import org.springframework.data.annotation.Id;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;


@Entity
@Table(name = "Clubs")
public class Club {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;


    public Club() {

    }


    @Override
    public String toString() {
        return "";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Club)) return false;

        Club club = (Club) o;

        if (getId() != club.getId()) return false;
        return false;
    }

    @Override
    public int hashCode() {
        int result = getId();

        return result;
    }

    @javax.persistence.Id
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
}
