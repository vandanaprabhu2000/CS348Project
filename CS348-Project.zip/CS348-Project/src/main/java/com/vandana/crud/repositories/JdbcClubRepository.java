package com.vandana.crud.repositories;

import com.vandana.crud.entities.Club;
import com.vandana.crud.entities.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class JdbcClubRepository implements ClubRepository {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public int save(Club club){
       // return jdbcTemplate.update("insert into clubs () values (?, ?)",
        //        student.getName(), student.getEmail());
        return 1;
    }
    @Override
    public int update(Club club){
       // return jdbcTemplate.update("update Students set name = ?, email = ? where student_id = ?",
       //         student.getName(), student.getEmail(), student.getId());
        return 1;
    }
    @Override
    public int deleteById(Integer id){
        return jdbcTemplate.update("delete from clubs where id = ?", id);
    }
    @Override
    public List<Club> findAll(){
      //  return jdbcTemplate.query("select * from students", (rs, rowNum) -> new Student(rs.getInt("student_id"),
      //          rs.getString("name"), rs.getString("email")
      //      )
          return new ArrayList<>();

    }
    public Optional<Club> findById(Integer id){
      //  return jdbcTemplate.queryForObject("select * from clubs where id = ?", new Object[]{id}, (rs, rowNum) ->
      //          Optional.of(new Club()
      //          ))
      //  );
        return null;
    }
}

