## Spring boot CRUD

This module contains articles about Spring Boot CRUD Operations

### Relevant Articles: 
- [Spring Boot CRUD Application with Thymeleaf](https://www.baeldung.com/spring-boot-crud-thymeleaf)
- [Using a Spring Boot Application as a Dependency](https://www.baeldung.com/spring-boot-dependency)
